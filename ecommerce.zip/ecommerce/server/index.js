const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());
port =5000


mongoose.connect("mongodb://localhost:27017/hammaddb");
   const db = mongoose.connection;
   db.on('error', console.error.bind(console, 'connection error:'));
   db.once('open', function() {
     console.log('Connected successfully to MongoDB');
   });

// mongo scheama
const datascheama = {
   name:String,
   email:String,
   id:Number
};

const modeldata = mongoose.model("database",datascheama);






app.listen(port,()=>{ console.log(`entered server : http://localhost:${port} `)})